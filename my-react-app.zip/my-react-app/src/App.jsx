import { useState } from 'react'
import { MyList } from './ListItem'

function App() {


  return (
    <MyList />
  )
}

export default App
