import React, { useState, useEffect } from 'react';

function ListItem(props) {
  return (
    <div>
      <h2>{props.item.name}</h2>
      <p>{props.item.description}</p>
    </div>
  );
}

export function MyList() {
  
  const [items, setItems] = useState([]);

  useEffect(() => {
    fetch('../src/data.json')
      .then(response => response.json())
      .then(data => setItems(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <ul>
      {items.map((item) => (
        <ListItem key={item.name} item={item} />
      ))}
    </ul>
  );
}